##################################################################
## Planejamento pre-experimental:
##################################################################
# 01. Reconhecimento e relato do problema;
# 02. Escolha dos fatores e dos niveis;
# 03. Selecao da variavel resposta;
# 04. Escolha do planejamento experimental;
# 05. Realizacao do experimento;
# 06. Analise dos dados;
# 07. Conclusoes e recomendacoes.

##################################################################
## Funcoes uteis:
##################################################################
# model coefficients: coefficients(fit) 
# CIs for model parameters: confint(fit, level=0.95) 
# predicted values: fitted(fit) 
# residuals: residuals(fit) 
# anova table: anova(fit) 
# covariance matrix for model parameters: vcov(fit) 
# regression diagnostics: influence(fit) 
##################################################################

# limpar area de trabalho
rm(list=ls(all=T))

# definir area de trabalho
setwd("/home/pcbrom/Dropbox/Trabalho e Estudo/SuperMetrica/Experimentacao_Fatorial/Modelo/Experimento_03_Safra_de_Trigo")

# instalar pacotes
#install.packages(c("lmtest", "car", "ggplot2", "FrF2", "DAAG"), dependencies = TRUE)

# carregar pacotes
require(lmtest); require(ggplot2); require(car); require(FrF2); require(DAAG)

##################################################################
# COLETA DE DADOS
##################################################################

# coletar os dados do experimento
#file.choose()
loc = "/home/pcbrom/Dropbox/Trabalho e Estudo/SuperMetrica/Experimentacao_Fatorial/Modelo/Experimento_03_Safra_de_Trigo/dados_experimento_03.csv"
dados = read.csv(loc)[,-1]

##################################################################
# AVALIACAO DO MODELO
##################################################################

# avaliacao do modelo
modelo_1.1 = lm(dados$safra.trigo ~ (dados$fertil + dados$precip), data = dados)
summary.lm(modelo_1.1)
anova(modelo_1.1)

# uma variavel afeta a outra, ou temos apenas efeito aditivo?
summary.lm(lm(dados$safra.trigo ~ (dados$fertil + dados$precip)^2, data = dados))

# Qual a contribuicao de cada variavel no modelo?
# para comparar quais variaveis contribuem mais para o modelo, padronizamos
# Xij* = (1/sqrt(n-1))*(Xij-Xi)/Si
# Yij* = (1/sqrt(n-1))*(Yij-Yi)/SY

# funcao para padronizar os dados
n = nrow(dados)
padronizar = function(n, obj) {(1/sqrt(n - 1))*(obj - mean(obj))/sd(obj)}

saf.t.p = padronizar(n, dados$safra.trigo)
fertil.p = padronizar(n, dados$fertil)
prec.p = padronizar(n, dados$precip)

dados = cbind(dados, saf.t.p, fertil.p, prec.p)

modelo_1.2 = lm(dados$saf.t.p ~ (dados$fertil.p + dados$prec.p - 1), data = dados)
summary.lm(modelo_1.2)

# como as variaveis se comportam duas a duas?
cor(dados)
plot(dados[,1:3])

# teste de Breusch-Pagan para homocedasticidade dos erros
bptest(modelo_1.1)

# avaliacao do ajuste do novo modelo
confint(modelo_1.1, level = 0.95) 
influenceIndexPlot(modelo_1.1, id.n = 3)
plot(modelo_1.1)

##################################################################
# MODELO FINAL
##################################################################

# regressao.1 com as variaveis estatisticamente significativas
regressao.1 = lm(modelo_1.1)

##################################################################
# ESCREVENDO AS FUNCOES DOS MODELOS
##################################################################

# funcao.1 para plotagem com as variaveis estatisticamente significativas
funcao.1 = function(x1,x2){
  regressao.1$coefficients[[1]] +       # intercepto
    regressao.1$coefficients[[2]]*x1 +  # variavel 1
    regressao.1$coefficients[[3]]*x2    # variavel 2
}

##################################################################
# GERANDO A MALHA DE RESPOSTA
##################################################################

# Criando a malha de valores de 
ax1 = min(dados$fertil); ax2 = max(dados$fertil)
bx1 = min(dados$precip); bx2 = max(dados$precip)
x1 = seq(ax1, ax2, by = (ax2-ax1)/20)    # "x1 := (eixo x)" e 
x2 = seq(bx1, bx2, by = (bx2-bx1)/20)    # "x2 := (eixo y)"

# Criando a malha do modelo
Resposta = outer(x1, x2, funcao.1)

##################################################################
# GRAFICOS
##################################################################

##################################################################
# Superficie de resposta
##################################################################

Fertilizante = x1; Precipitacao = x2

persp(Fertilizante, Precipitacao, Resposta, 
      main = "Superficie de Resposta\nSafra de Trigo",
      theta = -45,# REGIAO QUENTE PARA O LOCAL QUE QUEREMOS
      col = rev(heat.colors(400, alpha = 1)))

##################################################################
# Contorno: Valores otimos estao para a regiao mais quente
##################################################################

# Argumentos graficos
xlab = paste("Fertilizante de ", ax1, ' a ', ax2, sep = '', collapse = '')
ylab = paste("Precipitacao de ", bx1, ' a ', bx2, sep = '', collapse = '')
x = Fertilizante; y = Precipitacao; z = Resposta; n = 25; niveis.1 = seq(min(z), max(z), n/8)
titulo.1 = "Resposta em função de\nFertilizante e Precipitacao"

# Graficos

# funcao.1
filled.contour(x = x1, y = x2, z = z, # base de dados
  xlab = xlab, ylab = ylab, main = titulo.1, # rotulos e titulo
  col = rev(heat.colors(n, alpha = 1)), # paleta de cores
  xlim = c(ax1,ax2), ylim = c(bx1,bx2), plot.axes = { # curvas de nivel
  contour(x, y, z, nlevels = n, drawlabels = T, frame.plot = F, add = T, levels = niveis.1)
  axis(1); axis(2)})

##################################################################
# RETORNANDO AS CONDICOES OTIMAS DO SISTEMA
##################################################################

# ajustar a funcao.objetivo
funcao.objetivo = function(x1,x2) {funcao.1(x1,x2)}
x1.regiao = c(500,550); x2.valor = 15
x1.alvo = optimize(funcao.objetivo, x1.regiao, tol = 0.0001, x2 = x2.valor, maximum = T)
x1.alvo$maximum

# valores das funcoes para a coordenada otimizada
funcao.1(x1 = x1.alvo$maximum, x2 = x2.valor)

##################################################################
# FIM DA PROGRAMACAO
##################################################################

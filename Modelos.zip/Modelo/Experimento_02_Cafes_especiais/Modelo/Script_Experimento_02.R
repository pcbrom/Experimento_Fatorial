##################################################################
## Planejamento pre-experimental:
##################################################################
# 01. Reconhecimento e relato do problema;
# 02. Escolha dos fatores e dos niveis;
# 03. Selecao da variavel resposta;
# 04. Escolha do planejamento experimental;
# 05. Realizacao do experimento;
# 06. Analise dos dados;
# 07. Conclusoes e recomendacoes.

##################################################################
## Funcoes uteis:
##################################################################
# model coefficients: coefficients(fit) 
# CIs for model parameters: confint(fit, level=0.95) 
# predicted values: fitted(fit) 
# residuals: residuals(fit) 
# anova table: anova(fit) 
# covariance matrix for model parameters: vcov(fit) 
# regression diagnostics: influence(fit) 
##################################################################

# limpar area de trabalho
rm(list=ls(all=T))

# instalar pacotes
#install.packages(c("lmtest", "car", "ggplot2", "FrF2", "DAAG"), dependencies = TRUE)

# carregar pacotes
require(lmtest); require(ggplot2); require(car); require(FrF2); require(DAAG)

##################################################################
# COLETA DE DADOS
##################################################################

# coletar os dados do experimento
#file.choose()
loc = "/home/pcbrom/Dropbox/Trabalho e Estudo/SuperMetrica/Experimentacao_Fatorial/Modelo/Experimento_02_Cafes_especiais/Modelo/dados_experimento_02.csv"
dados = read.csv2(loc, dec = ',')

# coletar valores de referencia do experimento
#file.choose()
loc2 = "/home/pcbrom/Dropbox/Trabalho e Estudo/SuperMetrica/Experimentacao_Fatorial/Modelo/Experimento_02_Cafes_especiais/Modelo/valores_referencia_experimento_02.csv"
referencia = read.csv(loc2, dec = ',')

##################################################################
# AVALIACAO DO MODELO - conderamos aplha = 0.1
##################################################################

# avaliacao do modelo

# aroma
modelo_0.1 = glm(dados$Aroma.M ~ (dados$Qtd.Caf.Ag + dados$Qtd.Ag + dados$Gran), data = dados)
summary.glm(modelo_0.1)
# sabor
modelo_0.2 = glm(dados$Sabor.M ~ (dados$Qtd.Caf.Ag + dados$Qtd.Ag + dados$Gran), data = dados)
summary.glm(modelo_0.2)
# retrogosto
modelo_0.3 = glm(dados$Retrog.M ~ (dados$Qtd.Caf.Ag + dados$Qtd.Ag + dados$Gran), data = dados)
summary.glm(modelo_0.3)
# acidez
modelo_0.4 = glm(dados$Acidez.M ~ (dados$Qtd.Caf.Ag + dados$Qtd.Ag + dados$Gran), data = dados)
summary.glm(modelo_0.4)
# corpo
modelo_0.5 = glm(dados$Corpo.M ~ (dados$Qtd.Caf.Ag + dados$Qtd.Ag + dados$Gran), data = dados)
summary.glm(modelo_0.5)
# balanco
modelo_0.6 = glm(dados$Balanco.M ~ (dados$Qtd.Caf.Ag + dados$Qtd.Ag + dados$Gran), data = dados)
summary.glm(modelo_0.6)
# geral
modelo_0.7 = glm(dados$Geral.M ~ (dados$Qtd.Caf.Ag + dados$Qtd.Ag + dados$Gran), data = dados)
summary.glm(modelo_0.7)

# ajuste do modelo com as variaveis estatisticamente significativas
# aroma
modelo_1.1 = glm(dados$Aroma.M ~ (dados$Qtd.Ag + dados$Gran), data = dados)
# sabor
modelo_1.2 = glm(dados$Sabor.M ~ (dados$Qtd.Ag + dados$Gran), data = dados)
# retrogosto
modelo_1.3 = glm(dados$Retrog.M ~ (dados$Gran), data = dados)
# acidez
modelo_1.4 = glm(dados$Acidez.M ~ (dados$Qtd.Ag + dados$Gran), data = dados)
# corpo
modelo_1.5 = glm(dados$Corpo.M ~ (dados$Qtd.Ag + dados$Gran), data = dados)
# balanco
modelo_1.6 = glm(dados$Balanco.M ~ (dados$Gran), data = dados)
# balanco
modelo_1.7 = glm(dados$Geral.M ~ (dados$Qtd.Ag + dados$Gran), data = dados)

# teste de Breusch-Pagan para homocedasticidade dos erros
bptest(modelo_1.1)
bptest(modelo_1.2)
bptest(modelo_1.3)
bptest(modelo_1.4)
bptest(modelo_1.5)
bptest(modelo_1.6)
bptest(modelo_1.7)

# intervalos de confianca do novo modelo
confint(modelo_1.1, level = 0.95) 
confint(modelo_1.2, level = 0.95) 
confint(modelo_1.3, level = 0.95) 
confint(modelo_1.4, level = 0.95) 
confint(modelo_1.5, level = 0.95) 
confint(modelo_1.6, level = 0.95) 
confint(modelo_1.7, level = 0.95) 

##################################################################
# MODELO FINAL
##################################################################

# regressao.1 com as variaveis estatisticamente significativas
regressao.1 = lm(modelo_1.1)
regressao.2 = lm(modelo_1.2)
regressao.3 = lm(modelo_1.3)
regressao.4 = lm(modelo_1.4)
regressao.5 = lm(modelo_1.5)
regressao.6 = lm(modelo_1.6)
regressao.7 = lm(modelo_1.7)

##################################################################
# ESCREVENDO AS FUNCOES DOS MODELOS
##################################################################

# funcao.1 para plotagem com as variaveis estatisticamente significativas
funcao.1 = function(x1,x2){
    regressao.1$coefficients[[1]] + # intercepto
    regressao.1$coefficients[[2]]*x1 + # variavel 1
    regressao.1$coefficients[[3]]*x2   # variavel 2
}

funcao.2 = function(x1,x2){
    regressao.2$coefficients[[1]] + # intercepto
    regressao.2$coefficients[[2]]*x1 + # variavel 1
    regressao.2$coefficients[[3]]*x2   # variavel 2
}

funcao.3 = function(x2){
    regressao.3$coefficients[[1]] + # intercepto
    regressao.3$coefficients[[2]]*x2   # variavel 2
}

funcao.4 = function(x1,x2){
    regressao.4$coefficients[[1]] + # intercepto
    regressao.4$coefficients[[2]]*x1 + # variavel 1
    regressao.4$coefficients[[3]]*x2   # variavel 2
}

funcao.5 = function(x1,x2){
    regressao.5$coefficients[[1]] + # intercepto
    regressao.5$coefficients[[2]]*x1 + # variavel 1
    regressao.5$coefficients[[3]]*x2   # variavel 2
}

funcao.6 = function(x2){
    regressao.6$coefficients[[1]] + # intercepto
    regressao.6$coefficients[[2]]*x2   # variavel 2
}

funcao.7 = function(x1,x2){
    regressao.7$coefficients[[1]] + # intercepto
    regressao.7$coefficients[[2]]*x1 + # variavel 1
    regressao.7$coefficients[[3]]*x2   # variavel 2
}

##################################################################
# GERANDO A MALHA DE RESPOSTA
##################################################################

# Criando a malha de valores de 

# "x1 := Quantidade de Agua (eixo x)"
x1 = seq(from = referencia[1,3], to = referencia[2,3], by = 0.05)
# "x2 := Granulumetria FIN = 0 e GR = 1 (eixo y)"
x2 = seq(from = 0, to = 1, by = 0.05)

# Criando a malha do modelo
names(dados)

aroma = outer(x1, x2, funcao.1)
sabor = outer(x1, x2, funcao.2)
retrogosto = funcao.3(x2)
acidez = outer(x1, x2, funcao.4)
corpo = outer(x1, x2, funcao.5)
balanco = funcao.6(x2)
geral = outer(x1, x2, funcao.7)

##################################################################
# GRAFICOS
##################################################################

##################################################################
# Superficie de resposta
##################################################################

qtd.agua = x1
gran.fin.gr = x2

par(mfrow=c(2, 4))
    persp(qtd.agua, gran.fin.gr, aroma, 
          main = "Superficie de Resposta\nAroma",
          theta = 60,
          # REGIAO QUENTE PARA O LOCAL QUE QUEREMOS
          col = heat.colors(400, alpha = 1))
    persp(qtd.agua, gran.fin.gr, sabor, 
          main = "Superficie de Resposta\nSabor",
          theta = 60,
          # REGIAO QUENTE PARA O LOCAL QUE QUEREMOS
          col = heat.colors(400, alpha = 1))
    persp(gran.fin.gr, gran.fin.gr, (retrogosto)%*%t(retrogosto), 
          main = "Superficie de Resposta\nRetrogosto",
          theta = 60,
          # REGIAO QUENTE PARA O LOCAL QUE QUEREMOS
          col = rev(heat.colors(400, alpha = 1)))
    persp(qtd.agua, gran.fin.gr, acidez, 
          main = "Superficie de Resposta\nAcidez",
          theta = 60,
          # REGIAO QUENTE PARA O LOCAL QUE QUEREMOS
          col = rev(heat.colors(400, alpha = 1)))
    persp(qtd.agua, gran.fin.gr, corpo, 
          main = "Superficie de Resposta\nCorpo",
          theta = 60,
          # REGIAO QUENTE PARA O LOCAL QUE QUEREMOS
          col = (heat.colors(400, alpha = 1))) # o que queremos aqui?
    persp(gran.fin.gr, gran.fin.gr, (balanco)%*%t(balanco), 
          main = "Superficie de Resposta\nBalanço",
          theta = 60,
          # REGIAO QUENTE PARA O LOCAL QUE QUEREMOS
          col = heat.colors(400, alpha = 1))
    persp(qtd.agua, gran.fin.gr, geral, 
          main = "Superficie de Resposta\nGeral",
          theta = 60,
          # REGIAO QUENTE PARA O LOCAL QUE QUEREMOS
          col = heat.colors(400, alpha = 1))
par(mfrow=c(1, 1))


##################################################################
# AVALIACAO GEOMETRICA DA funcao.objetivo
##################################################################

# ajustar a funcao.objetivo
funcao.objetivo = function(x1,x2) {
    funcao.1(x1,x2)*funcao.2(x1,x2)*funcao.5(x1,x2)*funcao.6(x2)*
    funcao.7(x1,x2)/(funcao.3(x2)*funcao.4(x1,x2))
}

# malha de valores
func.obj = outer(x1, x2, funcao.objetivo)

# superficie de resposta
persp(qtd.agua, gran.fin.gr, func.obj, 
      main = "Superficie de Resposta\nfunc.obj",
      theta = 60,
      # REGIAO QUENTE PARA O LOCAL QUE QUEREMOS
      col = heat.colors(400, alpha = 1))

# contorno da funcao.bjetivo
n = 20; niveis.1 = seq(min(func.obj), max(func.obj), n/2)
filled.contour(x = x1, y = x2, z = func.obj, # base de dados
  main = "Funcao Objetivo", # rotulos e titulo
  col = rev(heat.colors(n, alpha = 1)), # paleta de cores
  xlim = c(1,2), ylim = c(0,1), xlab = "qtd.agua", ylab = "gran.fin.gr",
  plot.axes = { # curvas de nivel
    contour(x = x1, y = x2, z = func.obj, nlevels = n, drawlabels = T, frame.plot = F, add = T, levels = niveis.1)
    axis(1); axis(2)})


##################################################################
# RETORNANDO AS CONDICOES OTIMAS DO SISTEMA
##################################################################

x1.regiao = c(1.4, 1.6); x2.valor = 0
x1.alvo = optimize(funcao.objetivo, x1.regiao, tol = 0.0001, x2 = x2.valor, maximum = T)
x1.alvo$maximum

# valores das funcoes para a coordenada otimizada
funcao.1(x1 = x1.alvo$maximum, x2 = x2.valor); funcao.2(x1 = x1.alvo$maximum, x2 = x2.valor)

##################################################################
# ROBUSTEZ DO MODELO
##################################################################

# chamar os dados avaliados por um especialista
loc3 = "/home/pcbrom/Dropbox/Trabalho e Estudo/SuperMetrica/Experimentacao_Fatorial/Modelo/Experimento_02_Cafes_especiais/Modelo/dados_experimento_02_especialista.csv"
dados.esp = read.csv2(loc3, dec = ',')

# AROMA

distPred = predict(modelo_1.1, dados.esp)
actuals_preds = data.frame(cbind(actuals = dados.esp$Aroma.M, predicteds = distPred))
correlation_accuracy = cor(actuals_preds)

# min_max accuracy
min_max_accuracy = mean(apply(actuals_preds, 1, min)/apply(actuals_preds, 1, max))  
min_max_accuracy

# mean absolute percentage deviation
mape = mean(abs((actuals_preds$predicteds - actuals_preds$actuals))/actuals_preds$actuals)  
mape

# SABOR

distPred = predict(modelo_1.2, dados.esp)
actuals_preds = data.frame(cbind(actuals = dados.esp$Aroma.M, predicteds = distPred))
correlation_accuracy = cor(actuals_preds)

# min_max accuracy
min_max_accuracy = mean(apply(actuals_preds, 1, min)/apply(actuals_preds, 1, max))  
min_max_accuracy

# mean absolute percentage deviation
mape = mean(abs((actuals_preds$predicteds - actuals_preds$actuals))/actuals_preds$actuals)  
mape

# RETROGOSTO

distPred = predict(modelo_1.3, dados.esp)
actuals_preds = data.frame(cbind(actuals = dados.esp$Aroma.M, predicteds = distPred))
correlation_accuracy = cor(actuals_preds)

# min_max accuracy
min_max_accuracy = mean(apply(actuals_preds, 1, min)/apply(actuals_preds, 1, max))  
min_max_accuracy

# mean absolute percentage deviation
mape = mean(abs((actuals_preds$predicteds - actuals_preds$actuals))/actuals_preds$actuals)  
mape

# ACIDEZ

distPred = predict(modelo_1.4, dados.esp)
actuals_preds = data.frame(cbind(actuals = dados.esp$Aroma.M, predicteds = distPred))
correlation_accuracy = cor(actuals_preds)

# min_max accuracy
min_max_accuracy = mean(apply(actuals_preds, 1, min)/apply(actuals_preds, 1, max))  
min_max_accuracy

# mean absolute percentage deviation
mape = mean(abs((actuals_preds$predicteds - actuals_preds$actuals))/actuals_preds$actuals)  
mape

# CORPO

distPred = predict(modelo_1.1, dados.esp)
actuals_preds = data.frame(cbind(actuals = dados.esp$Aroma.M, predicteds = distPred))
correlation_accuracy = cor(actuals_preds)

# min_max accuracy
min_max_accuracy = mean(apply(actuals_preds, 1, min)/apply(actuals_preds, 1, max))  
min_max_accuracy

# mean absolute percentage deviation
mape = mean(abs((actuals_preds$predicteds - actuals_preds$actuals))/actuals_preds$actuals)  
mape

# BALANÇO

distPred = predict(modelo_1.1, dados.esp)
actuals_preds = data.frame(cbind(actuals = dados.esp$Aroma.M, predicteds = distPred))
correlation_accuracy = cor(actuals_preds)

# min_max accuracy
min_max_accuracy = mean(apply(actuals_preds, 1, min)/apply(actuals_preds, 1, max))  
min_max_accuracy

# mean absolute percentage deviation
mape = mean(abs((actuals_preds$predicteds - actuals_preds$actuals))/actuals_preds$actuals)  
mape

# GERAL

distPred = predict(modelo_1.1, dados.esp)
actuals_preds = data.frame(cbind(actuals = dados.esp$Aroma.M, predicteds = distPred))
correlation_accuracy = cor(actuals_preds)

# min_max accuracy
min_max_accuracy = mean(apply(actuals_preds, 1, min)/apply(actuals_preds, 1, max))  
min_max_accuracy

# mean absolute percentage deviation
mape = mean(abs((actuals_preds$predicteds - actuals_preds$actuals))/actuals_preds$actuals)  
mape

# QUEM SAO OS MELHORES AVALIADORES?

medias = colMeans(dados.esp[,5:11]); desv.p = apply(dados.esp[,5:11], 2, sd)

m.dp.baixo = medias - desv.p; m.dp.cima = medias + desv.p

media.aval = aggregate(dados[,5:11], by = list(dados$Avaliador), mean)
media.aval2 = media.aval[,-1]

nl = nrow(media.aval2); nc = ncol(media.aval2)
resultado = matrix(rep(F, nl*nc), nrow = nl, ncol = nc)
for (i in 1:nl) {
  for (j in 1:nc) {
    resultado[i,j] = media.aval2[i,j] >= m.dp.baixo[[j]] && media.aval2[i,j] <= m.dp.cima[[j]]
  }
}
resultado

rotulos = names(media.aval2)
avaliadores = 1:14
avaliadores = as.data.frame(cbind(avaliadores, "nota 0 -> 100" = round(100*apply(resultado, 1, sum)/7, 2)))
rotulos = as.data.frame(cbind(rotulos, "nota 0 -> 100" = round(100*apply(resultado, 2, sum)/14, 2)))

##################################################################
# FIM DA PROGRAMACAO
##################################################################

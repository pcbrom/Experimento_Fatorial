##################################################################
## Planejamento pre-experimental:
##################################################################
# 01. Reconhecimento e relato do problema;
# 02. Escolha dos fatores e dos niveis;
# 03. Selecao da variavel resposta;
# 04. Escolha do planejamento experimental;
# 05. Realizacao do experimento;
# 06. Analise dos dados;
# 07. Conclusoes e recomendacoes.

##################################################################
## Funcoes uteis:
##################################################################
# model coefficients: coefficients(fit) 
# CIs for model parameters: confint(fit, level=0.95) 
# predicted values: fitted(fit) 
# residuals: residuals(fit) 
# anova table: anova(fit) 
# covariance matrix for model parameters: vcov(fit) 
# regression diagnostics: influence(fit) 
##################################################################

# limpar area de trabalho
rm(list=ls(all=T))

# instalar pacotes
#install.packages(c("lmtest", "car", "ggplot2", "FrF2", "DAAG"), dependencies = TRUE)

# carregar pacotes
require(lmtest); require(ggplot2); require(car); require(FrF2); require(DAAG)

##################################################################
# COLETA DE DADOS
##################################################################

# coletar os dados do experimento -> dados_experimento_01.csv
loc = "/home/pcbrom/Dropbox/Trabalho e Estudo/SuperMetrica/Experimentacao_Fatorial/Modelo/Experimento_01_Gravacao_em_circuitos/dados_experimento_01.csv"
dados = read.csv(loc, dec = ',')

# coletar valores de referencia do experimento -> valores_referencia_experimento_01.csv
loc2 = "/home/pcbrom/Dropbox/Trabalho e Estudo/SuperMetrica/Experimentacao_Fatorial/Modelo/Experimento_01_Gravacao_em_circuitos/valores_referencia_experimento_01.csv"
referencia = read.csv(loc2, dec = ',')

##################################################################
# AVALIACAO DO MODELO
##################################################################

# avaliacao do modelo
names(dados)
modelo_0.1 = lm(dados$tx_gravacao ~ (dados$espacamento + dados$pressao + dados$fluxo + dados$potencia)^2, data = dados)
summary.lm(modelo_0.1)
modelo_0.2 = lm(dados$sd_tx_gravacao ~ (dados$espacamento + dados$pressao + dados$fluxo + dados$potencia)^2, data = dados)
summary.lm(modelo_0.2)

MEPlot(modelo_0.1)
MEPlot(modelo_0.2)
View(cor(dados[,-1]))

# ajuste do modelo com as variaveis estatisticamente significativas
modelo_1.1 = lm(dados$tx_gravacao ~ dados$espacamento + dados$potencia + dados$espacamento:dados$potencia, data = dados)
modelo_1.2 = lm(dados$sd_tx_gravacao ~ dados$espacamento + dados$espacamento:dados$potencia, data = dados)

# teste de Breusch-Pagan para homocedasticidade dos erros
bptest(modelo_1.1)
bptest(modelo_1.2)

# avaliacao do ajuste do novo modelo
confint(modelo_1.1, level = 0.95) 
plot(modelo_1.1)
influenceIndexPlot(modelo_1.1, id.n = 3)

confint(modelo_1.2, level = 0.95) 
plot(modelo_1.2)
influenceIndexPlot(modelo_1.2, id.n = 3)

# verificacao visual de outliers para as variaveis de resposta
par(mfrow=c(1, 2))
boxplot(dados$tx_gravacao, main = "tx")
boxplot(dados$sd_tx_gravacao, main = "sd_tx")
par(mfrow=c(1, 1))

# verificacao numerica de outliers para as variaveis de resposta
boxplot.stats(dados$tx_gravacao)
boxplot.stats(dados$sd_tx_gravacao)

##################################################################
# MODELO FINAL
##################################################################

# regressao.1 com as variaveis estatisticamente significativas
regressao.1 = lm(modelo_1.1)
print(regressao.1)

regressao.2 = lm(modelo_1.2)
print(regressao.2)

##################################################################
# ESCREVENDO AS FUNCOES DOS MODELOS
##################################################################

# funcao.1 para plotagem com as variaveis estatisticamente significativas
funcao.1 = function(x1,x2){
  regressao.1$coefficients[[1]] + # intercepto
    regressao.1$coefficients[[2]]*x1 + # variavel 1
    regressao.1$coefficients[[3]]*x2 + # variavel 2
    regressao.1$coefficients[[4]]*x1*x2 # variavel 1 e 2
}

# funcao.2 para plotagem com as variaveis estatisticamente significativas (alpha = 0.1)
funcao.2 = function(x1,x2){
  regressao.2$coefficients[[1]] + # intercepto
    regressao.2$coefficients[[2]]*x1 + # variavel 1
    regressao.2$coefficients[[3]]*x1*x2 # variavel 1 e 2
}

##################################################################
# GERANDO A MALHA DE RESPOSTA
##################################################################

# Criando a malha de valores de 
x1 = seq(from = -1, to = 1, by = 0.1)    # "x1 := espacamento (eixo x)" e 
x2 = seq(from = -1, to = 1, by = 0.1)    # "x2 := potencia (eixo y"

# Criando a malha do modelo
Taxa.Gravacao = outer(x1, x2, funcao.1)
sd.Taxa.Gravacao = outer(x1, x2, funcao.2)

##################################################################
# GRAFICOS
##################################################################

##################################################################
# Superficie de resposta
##################################################################

Espacamento = x1
Potencia = x2

par(mfrow=c(1, 2))
persp(Espacamento, Potencia, Taxa.Gravacao, 
      main = "Superficie de Resposta\nTx_Gravacao",
      theta = 45,
      # REGIAO QUENTE PARA O LOCAL QUE QUEREMOS
      col = rev(heat.colors(400, alpha = 1)))
persp(Espacamento, Potencia, sd.Taxa.Gravacao, 
      main = "Superficie de Resposta\nsd_Tx_Gravacao",
      theta = 45,
      # REGIAO QUENTE PARA O LOCAL QUE QUEREMOS
      col = rev(heat.colors(400, alpha = 1)))
par(mfrow=c(1, 1))

##################################################################
# Contorno: Valores otimos estao para a regiao mais quente
##################################################################

# Argumentos graficos
xlab = paste("Espacamento (cm) com variacao de ", 
             referencia[1,2], ' a ', referencia[2,2], sep = '', collapse = '')
ylab = paste("Potencia (W) com variacao de ", 
             referencia[1,5], ' a ', referencia[2,5], sep = '', collapse = '')

x = Espacamento; y = Potencia; z = Taxa.Gravacao
n = 25; niveis.1 = seq(min(z), max(z), n/2)
titulo.1 = "Taxa de Gravacao (A/m)"

escala = max(Taxa.Gravacao)/max(sd.Taxa.Gravacao)
w = sd.Taxa.Gravacao*escala; niveis.2 = seq(min(w), max(w), n/2)
titulo.2 = "SD Taxa de Gravacao (A/m) em escala"

# Graficos

# funcao.1
filled.contour(
  x = x1, y = x2, z = z, # base de dados
  xlab = xlab, ylab = ylab, main = titulo.1, # rotulos e titulo
  col = rev(heat.colors(n, alpha = 1)), # paleta de cores
  xlim = c(-1,1), ylim = c(-1,1),
  plot.axes = { # curvas de nivel
    contour(x, y, z, nlevels = n, drawlabels = T, frame.plot = F, add = T, levels = niveis.1)
    axis(1)
    axis(2)})

# funcao.2
filled.contour(
  x = x1, y = x2, z = w, # base de dados
  xlab = xlab, ylab = ylab, main = titulo.2, # rotulos e titulo
  col = heat.colors(n, alpha = 1), # paleta de cores
  xlim = c(-1,1), ylim = c(-1,1),
  plot.axes = { # curvas de nivel
    contour(x, y, w, nlevels = n, drawlabels = T, frame.plot = F, add = T, levels = niveis.2)
    axis(1)
    axis(2)})

##################################################################
# RETORNANDO AS CONDICOES OTIMAS DO SISTEMA
##################################################################

# ajustar a funcao.objetivo
funcao.objetivo = function(x1,x2) {
  funcao.1(x1,x2)/(escala*funcao.2(x1,x2))
}
x1.regiao = c(-0.1,0.3); x2.valor = 0.5
x1.alvo = optimize(funcao.objetivo, x1.regiao, tol = 0.0001, x2 = x2.valor, maximum = T)
x1.alvo$maximum

# valores das funcoes para a coordenada otimizada
funcao.1(x1 = x1.alvo$maximum, x2 = x2.valor); funcao.2(x1 = x1.alvo$maximum, x2 = x2.valor)

##################################################################
# AVALIACAO GEOMETRICA DA funcao.objetivo
##################################################################

# malha de valores
func.obj = outer(x1, x2, funcao.objetivo)

# superficie de resposta
persp(Espacamento, Potencia, func.obj, 
      main = "Superficie de Resposta\nfunc.obj",
      theta = -45,
      # REGIAO QUENTE PARA O LOCAL QUE QUEREMOS
      col = rev(heat.colors(400, alpha = 1)))

# contorno da funcao.bjetivo
filled.contour(
  x = x1, y = x2, z = func.obj, # base de dados
  xlab = xlab, ylab = ylab, main = "Funcao Objetivo", # rotulos e titulo
  col = rev(heat.colors(n, alpha = 1)), # paleta de cores
  xlim = c(-1,1), ylim = c(-1,1),
  plot.axes = { # curvas de nivel
    contour(x, y, z, nlevels = n, drawlabels = T, frame.plot = F, add = T, levels = niveis.1)
    axis(1); axis(2)}
)

##################################################################
# FIM DA PROGRAMACAO
##################################################################

##################################################################
## Planejamento pre-experimental:
##################################################################
# 01. Reconhecimento e relato do problema;
# 02. Escolha dos fatores e dos niveis;
# 03. Selecao da variavel resposta;
# 04. Escolha do planejamento experimental;
# 05. Realizacao do experimento;
# 06. Analise dos dados;
# 07. Conclusoes e recomendacoes.

##################################################################
## Funcoes uteis:
##################################################################
# model coefficients: coefficients(fit) 
# CIs for model parameters: confint(fit, level=0.95) 
# predicted values: fitted(fit) 
# residuals: residuals(fit) 
# anova table: anova(fit) 
# covariance matrix for model parameters: vcov(fit) 
# regression diagnostics: influence(fit) 
##################################################################

# limpar area de trabalho
rm(list=ls(all=T))

# instalar pacotes
#install.packages(c("lmtest", "car", "ggplot2", "FrF2", "DAAG"), dependencies = TRUE)

# carregar pacotes
require(lmtest); require(ggplot2); require(car); require(FrF2); require(DAAG)

##################################################################
# COLETA DE DADOS
##################################################################

# coletar os dados do experimento
#file.choose()
loc = "/home/pcbrom/Dropbox/Trabalho e Estudo/SuperMetrica/Experimentacao_Fatorial/Modelo/Oficina_Experimento_Helicoptero_de_papel/dados_oficina.csv"
dados = read.csv(loc, dec = ',')

# coletar valores de referencia do experimento
#file.choose()
loc2 = "/home/pcbrom/Dropbox/Trabalho e Estudo/SuperMetrica/Experimentacao_Fatorial/Modelo/Oficina_Experimento_Helicoptero_de_papel/valores_referencia_oficina.csv"
referencia = read.csv(loc2, dec = ',')

##################################################################
# AVALIACAO DO MODELO
##################################################################

# avaliacao do modelo
names(dados)
modelo_0.1 = glm(dados$Tempo_de_Voo ~ (dados$Tipo_de_papel + dados$Comprimento_do_rotor +
                 dados$Comprimento_da_perna + dados$Largura_da_perna +
                 dados$Clipe_de_papel_na_perna), data = dados)
summary(modelo_0.1)

# ajuste do modelo com as variaveis estatisticamente significativas
modelo_1.1 = glm(dados$Tempo_de_Voo ~ (dados$Tipo_de_papel + 
                 dados$Clipe_de_papel_na_perna), data = dados)
summary(modelo_1.1)

# teste de Breusch-Pagan para homocedasticidade dos erros
bptest(modelo_1.1)

# avaliacao do ajuste do novo modelo
confint(modelo_1.1, level = 0.95) 
plot(fitted(modelo_1.1), residuals(modelo_1.1)); abline(h = 0, col = "red")
influenceIndexPlot(modelo_1.1, id.n = 3)

# verificacao visual entre as variaveis de resposta
scatter.smooth(x = dados$Tempo_de_Voo, y = dados$Tipo_de_papel, main = "tipo_papel")
scatter.smooth(x = dados$Tempo_de_Voo, y = dados$Clipe_de_papel_na_perna, main = "clipe")

# verificacao visual de outliers para as variaveis de resposta
boxplot(dados$Tempo_de_Voo, main = "tempo_voo")

# verificacao numerica de outliers para as variaveis de resposta
boxplot.stats(dados$Tempo_de_Voo)

##################################################################
# MODELO FINAL
##################################################################

# regressao.1 com as variaveis estatisticamente significativas
regressao.1 = glm(modelo_1.1)
print(regressao.1)

##################################################################
# ESCREVENDO AS FUNCOES DOS MODELOS
##################################################################

# funcao.1 para plotagem com as variaveis estatisticamente significativas
funcao.1 = function(x1,x2){
  regressao.1$coefficients[[1]] + # intercepto
    regressao.1$coefficients[[2]]*x1 + # variavel 1
    regressao.1$coefficients[[3]]*x2 # variavel 2
}

##################################################################
# GERANDO A MALHA DE RESPOSTA
##################################################################

# Criando a malha de valores de 
x1 = seq(0, 1, by = 0.1)    # "x1 := (eixo x)" e 
x2 = seq(0, 1, by = 0.1)    # "x2 := (eixo y)"

# Criando a malha do modelo
Tempo_voo = outer(x1, x2, funcao.1)

##################################################################
# GRAFICOS
##################################################################

##################################################################
# Superficie de resposta
##################################################################

Tipo_papel = x1
Clipe = x2

persp(Tipo_papel, Clipe, Tempo_voo, 
      main = "Superficie de Resposta\nTempo_voo",
      theta = 60,
      # REGIAO QUENTE PARA O LOCAL QUE QUEREMOS
      col = rev(heat.colors(400, alpha = 1)))

##################################################################
# Contorno: Valores otimos estao para a regiao mais quente
##################################################################

# Argumentos graficos
xlab = paste("Tipo_papel com variacao de ", 
             referencia[1,2], ' a ', referencia[2,2], sep = '', collapse = '')
ylab = paste("Clipe com variacao de ", 
             referencia[1,6], ' a ', referencia[2,6], sep = '', collapse = '')

x = Tipo_papel; y = Clipe; z = Tempo_voo
n = 25; niveis.1 = seq(min(100*z), max(100*z), n/2)
titulo.1 = "Tempo_voo"

# Graficos

# funcao.1
filled.contour(x = x1, y = x2, z = 100*z, # base de dados
  xlab = xlab, ylab = ylab, main = titulo.1, # rotulos e titulo
  col = rev(heat.colors(n, alpha = 1)), # paleta de cores
  xlim = c(0,1), ylim = c(0,1), plot.axes = { # curvas de nivel
    contour(x, y, z, nlevels = n, drawlabels = T, frame.plot = F, add = T, levels = niveis.1)
    axis(1); axis(2)})

##################################################################
# RETORNANDO AS CONDICOES OTIMAS DO SISTEMA
##################################################################

# ajustar a funcao.objetivo
funcao.objetivo = function(x1,x2) {
  funcao.1(x1,x2)
}
x1.regiao = c(0,0.4); x2.valor = 0.2
x1.alvo = optimize(funcao.objetivo, x1.regiao, tol = 0.0001, x2 = x2.valor, maximum = T)
x1.alvo$maximum

# valores das funcoes para a coordenada otimizada
funcao.1(x1 = x1.alvo$maximum, x2 = x2.valor)

##################################################################
# AVALIACAO GEOMETRICA DA funcao.objetivo
##################################################################

# malha de valores
func.obj = outer(x1, x2, funcao.objetivo)

# superficie de resposta
persp(Tipo_papel, Clipe, func.obj, 
      main = "Superficie de Resposta\nfunc.obj",
      theta = 60,
      # REGIAO QUENTE PARA O LOCAL QUE QUEREMOS
      col = rev(heat.colors(400, alpha = 1)))

# contorno da funcao.bjetivo
filled.contour(x = x1, y = x2, z = func.obj, # base de dados
  xlab = xlab, ylab = ylab, main = "Funcao Objetivo", # rotulos e titulo
  col = rev(heat.colors(n, alpha = 1)), # paleta de cores
  xlim = c(0,1), ylim = c(0,1), plot.axes = { # curvas de nivel
    contour(x, y, z, nlevels = n, drawlabels = T, frame.plot = F, add = T, levels = niveis.1)
    axis(1); axis(2)})

##################################################################
# ROBUSTEZ DO MODELO
##################################################################

# row indices for training data
trainingRowIndex = sample(1:nrow(dados), 0.7*nrow(dados))

# model training data
trainingData = dados[trainingRowIndex, ]

# test data
testData  = dados[-trainingRowIndex, ]

# build the model
lmMod = lm(trainingData$Tempo_de_Voo ~ (trainingData$Tipo_de_papel + 
           trainingData$Clipe_de_papel_na_perna), data = trainingData)

# predict
distPred = predict(lmMod, testData)

# summary
summary(lmMod)

# make actuals_predicteds dataframe
actuals_preds = data.frame(cbind(actuals = testData$Tempo_de_Voo, predicteds = distPred))
actuals_preds

# accuracy
correlation_accuracy = cor(actuals_preds)
correlation_accuracy
actuals_preds

# min_max accuracy
min_max_accuracy = mean(apply(actuals_preds, 1, min)/apply(actuals_preds, 1, max))  
min_max_accuracy

# mean absolute percentage deviation
mape = mean(abs((actuals_preds$predicteds - actuals_preds$actuals))/actuals_preds$actuals)  
mape

# performs the CV
cvResults = suppressWarnings(
  CVlm(data = dados, form.lm = lm(modelo_1.1), m = 1, 
       dots = FALSE, legend.pos = "topleft",  printit = FALSE, 
       main = "Pequenos símbolos são os valores previstos,\nenquanto os maiores são os valores reais")
)

# mean squared error
attr(cvResults, 'ms')

##################################################################
# FIM DA PROGRAMACAO
##################################################################

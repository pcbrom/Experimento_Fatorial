##################################################################
# CRIANDO AS RODADAS ALEATORIZADAS DO EXPERIMENTO
##################################################################

# Carregar os pacores necessarios:
require(FrF2); require(daewr)

# Indicar as variaveis de controle:
variaveis = c(1:4)

# Indicar os niveis de cada variavel:
niveis = c("baixo" = -1, "alto" = 1)

# Total de experimentos possiveis:
n.experimentos = 2^(length(variaveis))

# Matriz das rodadas possiveis:
rodadas = FrF2(nruns = n.experimentos, nfactors = length(variaveis), randomize = T)
names(rodadas) = variaveis
print(rodadas)
write.csv(rodadas, "/home/pcbrom/Downloads/rodadas.csv")

##################################################################
# FIM DA PROGRAMACAO
##################################################################
